将附件解压，放置在  catcod Release 1.1.0 fix2\data\flutter_assets\asset\js 目录下即可 
更多信息，可在https://github.com/gaotianliuyun/gao/tree/master/cat/js 查询

